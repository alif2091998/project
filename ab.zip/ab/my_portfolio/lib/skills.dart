import 'package:flutter/material.dart';

class SkillsPage extends StatelessWidget {
  // Sample data for skills
  final List<String> skills = [
    'Flutter',
    'Dart',
    'JavaScript',
    'React',
    'HTML',
    'CSS',
    'Firebase',
    'Git',
    'UI/UX Design',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Skills'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Skills:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            // Create a list of skills using ListView.builder
            ListView.builder(
              shrinkWrap: true,
              itemCount: skills.length,
              itemBuilder: (context, index) {
                final skill = skills[index];
                return ListTile(
                  leading: Icon(Icons.check_circle),
                  title: Text(skill),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
