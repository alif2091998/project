import 'package:flutter/material.dart';

class PortfolioPage extends StatelessWidget {
  // Sample data for portfolio items
  final List<Map<String, String>> portfolioItems = [
    {
      'title': 'Project 1',
      'description':
          'This is a description of my first project. It was a great learning experience.',
      'image': 'assets/project1.jpg', // Replace with actual image path
    },
    {
      'title': 'Project 2',
      'description':
          'My second project involved building a mobile app from scratch.',
      'image': 'assets/project2.jpg', // Replace with actual image path
    },
    // Add more portfolio items as needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Portfolio'),
      ),
      body: ListView.builder(
        itemCount: portfolioItems.length,
        itemBuilder: (context, index) {
          final item = portfolioItems[index];
          return ListTile(
            title: Text(item['title']!),
            subtitle: Text(item['description']!),
            leading: Image.asset(
              item['image']!,
              width: 80,
              height: 80,
              fit: BoxFit.cover,
            ),
          );
        },
      ),
    );
  }
}
