import 'package:flutter/material.dart';

class ExperiencesPage extends StatelessWidget {
  // Sample data for experiences
  final List<Map<String, String>> experiences = [
    {
      'title': 'Software Developer',
      'company': 'ABC Tech Solutions',
      'duration': 'Jan 2020 - Present',
    },
    {
      'title': 'Web Developer',
      'company': 'XYZ Web Services',
      'duration': 'May 2018 - Dec 2019',
    },
    // Add more experiences as needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Experiences'),
      ),
      body: ListView.builder(
        itemCount: experiences.length,
        itemBuilder: (context, index) {
          final experience = experiences[index];
          return ListTile(
            title: Text(experience['title']!),
            subtitle: Text(experience['company']!),
            trailing: Text(experience['duration']!),
          );
        },
      ),
    );
  }
}
