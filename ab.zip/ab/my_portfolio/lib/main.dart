import 'package:flutter/material.dart';

class WorkPage extends StatelessWidget {
  // Sample data for work experiences
  final List<Map<String, String>> workExperiences = [
    {
      'title': 'Software Developer',
      'company': 'ABC Tech Solutions',
      'duration': 'Jan 2020 - Present',
      'description':
          'Developed and maintained software applications for clients, ensuring high-quality code and on-time delivery.',
    },
    {
      'title': 'Web Developer',
      'company': 'XYZ Web Services',
      'duration': 'May 2018 - Dec 2019',
      'description':
          'Designed and implemented web applications, collaborated with cross-functional teams, and optimized user interfaces.',
    },
    // Add more work experiences or projects as needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Work'),
      ),
      body: ListView.builder(
        itemCount: workExperiences.length,
        itemBuilder: (context, index) {
          final experience = workExperiences[index];
          return Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  experience['title']!,
                  style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 4.0),
                Text(
                  experience['company']!,
                  style: TextStyle(
                    color: Colors.grey,
                  ),
                ),
                Text(
                  experience['duration']!,
                  style: TextStyle(
                    color: Colors.grey,
                  ),
                ),
                SizedBox(height: 8.0),
                Text(
                  experience['description']!,
                  style: TextStyle(fontSize: 16.0),
                ),
                Divider(), // Add a divider between work experiences
              ],
            ),
          );
        },
      ),
    );
  }
}
