package com.example.my_portfolio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
