package com.example.ab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
